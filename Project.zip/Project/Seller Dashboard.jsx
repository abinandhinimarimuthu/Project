
module.exports = {
  // Check if the user is an owner (admin)
  checkRole: (req, res, next) => {
    if (req.user && req.user.role === 'owner') {
      return next();
    }
    res.status(403).json({ error: 'Unauthorized access' });
  }
};
// src/routes/ownerRoutes.js
const express = require('express');
const { checkRole } = require('../middleware/authMiddleware'); // Import the role check middleware

const router = express.Router();

// Protected route for managing sellers (only for owners)
router.use('/manage-sellers', checkRole);

router.get('/manage-sellers', (req, res) => {
  // Only the owner can access this route
  res.send('Manage sellers dashboard');
});

module.exports = router;

