// src/controllers/authController.js
const nodemailer = require('nodemailer');
const crypto = require('crypto');
const User = require('../models/User'); // Assuming a User model exists

// Send registration email with verification token
module.exports.register = (req, res) => {
  const { email, password } = req.body;
  const verificationToken = crypto.randomBytes(20).toString('hex'); // Generate a verification token

  const newUser = new User({
    email,
    password,
    verificationToken,
    verified: false
  });

  newUser.save()
    .then(user => {
      // Send verification email
      const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
          user: 'your-email@gmail.com',
          pass: 'your-email-password',
        },
      });

      const verificationUrl = `http://localhost:3000/verify-email?token=${verificationToken}`;
      const mailOptions = {
        from: 'no-reply@website.com',
        to: email,
        subject: 'Verify Your Email',
        text: `Please verify your email by clicking the link: ${verificationUrl}`,
      };

      transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
          return res.status(500).json({ error: 'Failed to send verification email' });
        }
        res.status(201).json({ message: 'Verification email sent' });
      });
    })
    .catch(err => res.status(500).json({ error: 'Failed to register user' }));
};

// Verify email
module.exports.verifyEmail = (req, res) => {
  const { token } = req.query;

  User.findOne({ verificationToken: token })
    .then(user => {
      if (!user) {
        return res.status(400).json({ error: 'Invalid or expired token' });
      }

      // Mark the user as verified
      user.verified = true;
      user.verificationToken = undefined; // Remove the token after verification
      user.save()
        .then(() => res.json({ message: 'Email successfully verified' }))
        .catch(err => res.status(500).json({ error: 'Failed to verify email' }));
    });
};
