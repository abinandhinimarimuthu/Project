const express = require('express');
const multer = require('multer');
const path = require('path');
const Product = require('../models/Product'); // Assuming you have a Product model

const router = express.Router();

// Set up multer for image uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, './uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});

const upload = multer({
  storage: storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB max file size
  fileFilter: (req, file, cb) => {
    const filetypes = /jpeg|jpg|png|gif/;
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = filetypes.test(file.mimetype);

    if (extname && mimetype) {
      return cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'));
    }
  }
}).array('productImages', 5); // Allows up to 5 images per product

// Route for uploading product images
router.post('/upload-product-images', upload, (req, res) => {
  const imagePaths = req.files.map(file => file.path); // Store the file paths in the database
  res.json({ success: true, imagePaths });
});

module.exports = router;
