const axios = require('axios');

const shiprocketLogin = async () => {
    const response = await axios.post('https://apiv2.shiprocket.in/v1/external/auth/login', {
        email: process.env.SHIPROCKET_EMAIL,
        password: process.env.SHIPROCKET_PASSWORD,
    });
    return response.data.token;
};

const createOrder = async (orderDetails, token) => {
    const response = await axios.post(
        'https://apiv2.shiprocket.in/v1/external/orders/create/adhoc',
        orderDetails,
        {
            headers: { Authorization: `Bearer ${token}` },
        }
    );
    return response.data;
};

module.exports = { shiprocketLogin, cresateOrder };
