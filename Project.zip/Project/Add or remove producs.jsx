// src/routes/productRoutes.js
const express = require('express');
const Product = require('../models/Product'); // Assuming a Product model exists

const router = express.Router();

// Add Product (POST)
router.post('/add-product', (req, res) => {
  const { name, price, description, images } = req.body; // Get product details from the request body

  if (!name || !price || !description || !images || images.length === 0) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const newProduct = new Product({
    name,
    price,
    description,
    images,
    sellerId: req.user._id, // Assuming seller info is stored in req.user
  });

  newProduct.save()
    .then(product => res.status(201).json(product))
    .catch(err => res.status(500).json({ error: 'Failed to add product' }));
});

// Remove Product (DELETE)
router.delete('/remove-product/:productId', (req, res) => {
  const productId = req.params.productId;

  // Find the product and check if the seller is the owner of the product
  Product.findOne({ _id: productId, sellerId: req.user._id })
    .then(product => {
      if (!product) {
        return res.status(404).json({ error: 'Product not found or not owned by the seller' });
      }

      // Remove the product
      product.remove()
        .then(() => res.json({ success: true }))
        .catch(err => res.status(500).json({ error: 'Failed to remove product' }));
    });
});

module.exports = router;
