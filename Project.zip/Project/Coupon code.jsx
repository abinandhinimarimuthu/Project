// src/routes/couponRoutes.js
const express = require('express');
const Coupon = require('../models/Coupon'); // Assuming a Coupon model exists

const router = express.Router();

// Create Coupon (POST)
router.post('/create-coupon', (req, res) => {
  const { code, discount, expiryDate, usageLimit } = req.body;

  const newCoupon = new Coupon({
    code,
    discount,
    expiryDate,
    usageLimit,
  });

  newCoupon.save()
    .then(coupon => res.status(201).json(coupon))
    .catch(err => res.status(500).json({ error: 'Failed to create coupon' }));
});

// Apply Coupon (POST)
router.post('/apply-coupon', (req, res) => {
  const { code, orderAmount } = req.body;

  Coupon.findOne({ code })
    .then(coupon => {
      if (!coupon) {
        return res.status(404).json({ error: 'Invalid coupon code' });
      }

      // Check if the coupon has expired
      if (new Date() > coupon.expiryDate) {
        return res.status(400).json({ error: 'Coupon expired' });
      }

      // Apply discount
      const discountAmount = (orderAmount *
