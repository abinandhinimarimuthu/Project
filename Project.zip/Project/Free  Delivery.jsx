router.post('/create-order', async (req, res) => {
    try {
        const { items, totalAmount } = req.body;
        let finalAmount = totalAmount;

        // Apply free delivery
        if (totalAmount >= 499) {
            finalAmount -= 50; // Assuming delivery charge is ₹50
        }

        // Apply 10% off
        if (totalAmount >= 499) {
            finalAmount *= 0.9;
        }

        const newOrder = await Order.create({ items, totalAmount, finalAmount });
        res.status(200).json({ success: true, order: newOrder });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});
